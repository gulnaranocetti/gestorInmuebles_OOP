#ifndef CASA_H
#define CASA_H
#include "Inmueble.h"
#include "TipoTecho.h"
#include <string>
#include "TipoInmueble.h"

class Casa : public Inmueble {
    private:
        bool esPH;
        TipoTecho techo;

    public: 
        Casa(int codigo, std::string direccion, int numeroPuerta, int superficie, int anoConstruccion, bool esPH, TipoTecho techo);
        bool getEsPH();
        TipoTecho getTecho();
        TipoInmueble getTipo();
        Casa* getCasa();
        Apartamento* getApto();
        ~Casa();
};

#endif