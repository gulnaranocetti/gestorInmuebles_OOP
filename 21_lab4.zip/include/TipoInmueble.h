#ifndef TIPOINMUEBLE_H
#define TIPOINMUEBLE_H

enum TipoInmueble {
    Todos,
    CasaEnum,
    ApartamentoEnum
};

#endif